# PySineWave
Simple and lightweight package to generate and play (in real time) sine waves that can make smooth, continuous transitions in pitch and volume.